# TOPSIS Implementation in Python

This project provides a **command-line implementation of the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)** method using Python.  
It allows ranking of alternatives based on multiple criteria, weights, and impacts.

--------------------------------

# What is TOPSIS?

TOPSIS is a **multi-criteria decision-making (MCDM)** technique used to rank alternatives by comparing their distances from an **ideal best** and an **ideal worst** solution.

The best alternative:
- Has the **shortest distance from the ideal best**
- Has the **farthest distance from the ideal worst**

--------------------------------

# Project Structure
```
102303542_TOPSIS/
│
├── topsis/
│ ├── init.py
│ └── topsis.py
│ # Main TOPSIS implementation (CLI)
│
├── plot_graphs.py
│ # Script to generate graphs
│
├── README.md
│ # Project documentation
│
├── .gitignore
│
├── Topsis-Dataset.csv
│ # Sample input dataset
│
├── text_classification_result.csv
│ # Example TOPSIS output
│
├── modelResults.csv
│
├── topsis_scores.png
│ # TOPSIS score graph
│
└── topsis_ranking.png
# Ranking graph
```
-----------------------------------

# Requirements

- Python 3.x
- numpy
- pandas
- matplotlib(for graphs)

Install dependencies using:
pip install numpy pandas matplotlib

-------------------------------------

# Usage(Command Line)
python topsis.py <InputDataFile> <Weights> <Impacts> <ResultFileName>

Generate graphs using: 
python plot_graphs.py

Parameters:
InputDataFile → CSV file with alternatives and criteria
Weights → Comma-separated weights
Impacts → + for benefit, - for cost
ResultFileName → Output CSV file (auto-generated)

Input File Format:
First column: Alternative names
Remaining columns: Numeric criteria

